package com.oracle.oep.event;

public class DispatchEvent {
    
    public DispatchEvent() {
        super();
    }
    
    private String dispatchId;
    private String statusCode;
    private String serviceClass;
    private String serviceTag;
    private int slaEnd ;

    /**
     * @param dispatchId
     */
    public void setDispatchId(String dispatchId) {
        this.dispatchId = dispatchId;
    }

    public String getDispatchId() {
        return dispatchId;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setServiceClass(String serviceClass) {
        this.serviceClass = serviceClass;
    }

    public String getServiceClass() {
        return serviceClass;
    }

    public void setServiceTag(String serviceTag) {
        this.serviceTag = serviceTag;
    }

    public String getServiceTag() {
        return serviceTag;
    }


    public void setSlaEnd(int slaEnd) {
        this.slaEnd = slaEnd;
    }

    public int getSlaEnd() {
        return slaEnd;
    }

    @Override
    public String toString() {
        
        return "DispatchEvent [dispatchId=" + dispatchId 
                            + ", statusCode=" + statusCode 
                            + ", serviceClass=" + serviceClass
                            + ", serviceTag=" + serviceTag 
                            + ", slaEnd=" + slaEnd 
                            +  "]";
        
    }

    


}
