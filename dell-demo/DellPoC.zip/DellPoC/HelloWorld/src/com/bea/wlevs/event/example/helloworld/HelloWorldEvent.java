/* (c) 2006-2014 Oracle.  All rights reserved. */
package com.bea.wlevs.event.example.helloworld;

public class HelloWorldEvent {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage (String message) {
		this.message = message;
	}
}
